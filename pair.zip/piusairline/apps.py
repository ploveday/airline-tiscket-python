from django.apps import AppConfig


class PiusairlineConfig(AppConfig):
    name = 'piusairline'
